import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "./supabaseClient";

export default function JoinRoomPage() {
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [slot, setSlot] = useState(1);
  const navigate = useNavigate();

  const joinRoom = async () => {
    const { data: room } = await supabase
      .from("rooms")
      .select("id")
      .eq("code", code)
      .single();

    if (!room) return alert("Room not found");

    await supabase.from("players").insert([
      { room_id: room.id, name, slot, score: 0 }
    ]);

    navigate(`/control/${room.id}?slot=${slot}`);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Join a Room</h2>
      <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Room Code" />
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your Name" />
      <select value={slot} onChange={(e) => setSlot(Number(e.target.value))}>
        {[1, 2, 3, 4].map(n => <option key={n} value={n}>Slot {n}</option>)}
      </select>
      <button onClick={joinRoom}>Join</button>
    </div>
  );
}
