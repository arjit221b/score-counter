import { useEffect, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { supabase } from "./supabaseClient";

export default function ScoreControl() {
  const { roomId } = useParams();
  const [searchParams] = useSearchParams();
  const slot = Number(searchParams.get("slot"));
  const [player, setPlayer] = useState(null);

  useEffect(() => {
    const fetchPlayer = async () => {
      const { data } = await supabase
        .from("players")
        .select("*")
        .eq("room_id", roomId)
        .eq("slot", slot)
        .single();
      if (data) setPlayer(data);
    };
    fetchPlayer();
  }, [roomId, slot]);

  const changeScore = async (delta) => {
    if (!player) return;
    const { data } = await supabase
      .from("players")
      .update({ score: player.score + delta })
      .eq("id", player.id)
      .select()
      .single();
    if (data) setPlayer(data);
  };

  const resetScore = async () => {
    if (!player) return;
    const { data } = await supabase
      .from("players")
      .update({ score: 0 })
      .eq("id", player.id)
      .select()
      .single();
    if (data) setPlayer(data);
  };

  if (!player) return <p>Loading...</p>;

  return (
    <div style={{
      padding: 40,
      textAlign: "center",
      background: "#f5f5f5",
      borderRadius: "12px",
      margin: "20px"
    }}>
      <h2>{player.name} (User {player.slot})</h2>
      <h1 style={{ fontSize: "60px", margin: "20px 0" }}>{player.score}</h1>
      <button onClick={() => changeScore(1)} style={btn}>+1</button>
      <button onClick={() => changeScore(-1)} style={btn}>-1</button>
      <button onClick={resetScore} style={{ ...btn, background: "#9e9e9e" }}>Reset</button>
    </div>
  );
}

const btn = {
  margin: "10px",
  padding: "12px 24px",
  fontSize: "18px",
  border: "none",
  borderRadius: "8px",
  background: "#2196f3",
  color: "white",
  cursor: "pointer"
};
