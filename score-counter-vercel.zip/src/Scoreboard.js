import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "./supabaseClient";

const colors = ["#EF9A9A", "#CE93D8", "#90CAF9", "#A5D6A7", "#FFF59D", "#FFCC80"];

export default function Scoreboard({ roomId: propRoomId }) {
  const params = useParams();
  const roomId = propRoomId || params.roomId;
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    const fetchPlayers = async () => {
      const { data } = await supabase
        .from("players")
        .select("*")
        .eq("room_id", roomId)
        .order("slot", { ascending: true });
      if (data) setPlayers(data);
    };
    fetchPlayers();

    const channel = supabase
      .channel("realtime-players")
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "players",
        filter: `room_id=eq.${roomId}`,
      }, fetchPlayers)
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [roomId]);

  return (
    <div style={{ padding: 20 }}>
      <h2>Scoreboard</h2>
      {players.map((p, index) => (
        <div key={p.id} style={{
          background: colors[index % colors.length],
          padding: "20px",
          margin: "10px 0",
          borderRadius: "10px",
          fontSize: "18px"
        }}>
          <strong>{p.name}</strong> (User {p.slot}) — <b>Score: {p.score}</b>
        </div>
      ))}
    </div>
  );
}
