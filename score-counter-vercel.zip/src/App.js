import React from "react";
import { HashRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Home";
import CreateRoomPage from "./CreateRoomPage";
import JoinRoomPage from "./JoinRoomPage";
import ScoreControl from "./ScoreControl";
import Scoreboard from "./Scoreboard";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/create" element={<CreateRoomPage />} />
        <Route path="/join" element={<JoinRoomPage />} />
        <Route path="/control/:roomId" element={<ScoreControl />} />
        <Route path="/room/:roomId" element={<Scoreboard />} />
      </Routes>
    </Router>
  );
}
