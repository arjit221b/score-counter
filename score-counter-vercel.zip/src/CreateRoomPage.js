import { useEffect, useState } from "react";
import { supabase } from "./supabaseClient";
import Scoreboard from "./Scoreboard";

export default function CreateRoomPage() {
  const [room, setRoom] = useState(null);

  useEffect(() => {
    const createRoom = async () => {
      const { data, error } = await supabase
        .from("rooms")
        .insert([{}])
        .select("id, code")
        .single();
      if (error) return alert("Error creating room");
      setRoom(data);
    };
    createRoom();
  }, []);

  if (!room) return <p>Creating room...</p>;

  return (
    <div>
      <h2>Room Code: <code>{room.code}</code></h2>
      <Scoreboard roomId={room.id} />
    </div>
  );
}
